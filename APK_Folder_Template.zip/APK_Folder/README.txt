APK Folder Placeholder

This folder represents where an APK would go.
Example:
- PrimalMenu_Quest.apk

Use for documentation or private testing only.