# PrimalMenu (Quest-Only)

Quest-only Gorilla Tag tools focused on **private/modded lobbies** and **UI experimentation**.

## Platform
- Meta Quest / Quest 2 / Quest 3
- Android (ARM64)
- Unity IL2CPP

## What This Repo Is
- Static website (GitHub Pages-ready)
- Download placeholders (docs/templates)
- Original branding

## What This Repo Is Not
- No public-lobby tools
- No network or anti-cheat bypass
- No copied assets

## Install (Quest)
1. Download a ZIP from the site
2. Extract
3. Use SideQuest to install APK (when provided privately)

## License
Educational / private use.